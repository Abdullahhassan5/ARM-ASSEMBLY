#include "button.h"
#include "lpc17xx.h"

#include "../led/led.h"
int Value=0;
int count=0;
int ledout, ledout2;
void EINT0_IRQHandler (void)	  
{
	ledout = restoringSquareRoot(Value,count);
	
	
	ledout &= 255;		//only 8 bits remain in ledout
	LED_On(ledout);
	LPC_SC->EXTINT |= (1 << 0);     /* clear pending interrupt         */
	count = 0;				
	Value = 0;
}


void EINT1_IRQHandler (void)	  
{
	Value = (Value << 1);
	count++;
	LPC_SC->EXTINT |= (1 << 1);     /* clear pending interrupt         */
}

void EINT2_IRQHandler (void)	  
{
 	Value = (Value << 1);
	Value = Value + 1 ;
	count++;
	LPC_SC->EXTINT |= (1 << 2);     /* clear pending interrupt         */    
}


